from pyegeria import EgeriaTech

print("meow")